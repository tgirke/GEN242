cluster.functions = makeClusterFunctionsSlurm(template="slurm.tmpl")
